//Clase sellada
/*
sealed class ValorNumeroComidaFlexible
class Desayuno(val numeroComida : Int) : ValorNumeroComidaFlexible()
class Almuerzo(val numeroComida : Int) : ValorNumeroComidaFlexible()
//class Once(val numeroComida : Int) : ValorNumeroComidaFlexible()
class Cena(val numeroComida : Int) : ValorNumeroComidaFlexible()
class Colacion(val numeroComida : Int) : ValorNumeroComidaFlexible()
*/