/*
En Kotlin las clases por defecto son finales. No se pueden
heredar de dicha clase.
Para poder ser heredadas las declaramos con la
palabra reservada "open"
 */

//Generacion de objetos

//POJO
//forma 1
/*
data class Comida(
    var tipoComida: String = "Sin tipo corto",
    var numeroDeComida: Int = 0
)
*/

//forma 2
//POJO
open class Comida{
    var tipoComida: String
    var numeroDeComida: Int
    //constructor
    constructor(){
        tipoComida = "Sin Tipo"
        numeroDeComida = 0
    }

    //Sobrecarga del constructor
    constructor(tipo: String, numero: Int){
        tipoComida = tipo
        numeroDeComida = numero
    }
}
