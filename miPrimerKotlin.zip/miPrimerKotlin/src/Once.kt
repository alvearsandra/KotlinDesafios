/*
Para poder utilizar la herencia usaremos los dos puntos ":"
 */
//class Once : Comida(tipo="vegan", numero=1)
//class Once : Comida("vegan", 1)
class Once : Comida() {
    //el cuerpo de la clase
}