//Clases decoradores o enumeradas
//Clases selladas
enum class ValorNumeroComida(val numeroComida : Int) {
    Desayuno(1),
    Almuerzo(2),
    Once(3),
    Cena(4),
    Colacion(5)
}