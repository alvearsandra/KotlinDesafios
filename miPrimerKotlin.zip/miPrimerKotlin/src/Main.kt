//funcion main, es la principal, una de las mas importantes... me permite ejecutar mi app
fun main(){
    //Si esto funciona, puede poner en su CV que domina Kotlin
    println("Holi Mundi")

    /*
    * Variables
    * */
    //Variables inmutables -> se declaran con val
    //no cambiar valor, ni tipo (son similares a las constantes)
    val casiConstante = "mi primer casi constante"
    println(casiConstante)
    //casiConstante = "nuevo valor"
    val casiConstanteNumerica = 55
    println(casiConstanteNumerica)

    //Variables mutables -> se declaran con var
    //cambian su valor, pero no el tipo de dato
    var variable = "mi primer varible"
    println(variable)
    variable = "cambio su valor, porque es variable"
    println(variable)
    //variable = 13
    //println(variable)
    var variableNumerica = 55
    println(variableNumerica)
    //Concatenado
    println("Concatenado el ultimo valor, de la varible: $variable")
    println("Intentando concatenar mi string con mi variableNumerica: $variableNumerica")
    //Concatenado llamando a una funcion
    println("La variable, de nombre variable, tiene ${variable.count()} caracteres")
    var numeroCaracteres = variable.count()
    println(numeroCaracteres)
    var numeroCaracteresConcatenados = "La variable, de nombre variable, tiene ${variable.count()} caracteres"
    println(numeroCaracteresConcatenados)

    //Operacion matematica
    val numeroUno = 5
    val numeroDos = 10
    val numeroTres = 15
    var resultado = numeroUno + numeroDos + numeroTres
    println("la suma de $numeroUno + $numeroDos + $numeroTres es $resultado")
    resultado = numeroUno - numeroDos - numeroTres
    println("la resta de $numeroUno - $numeroDos - $numeroTres es $resultado")
    resultado = (numeroUno + numeroDos + numeroTres)/3
    println("el promedio de $numeroUno , $numeroDos , $numeroTres es $resultado")
/*
Tipos numericos en kotlin:
-Byte -> 8 bits
-Short -> 16 bits
-Int -> 32 bits
-Long -> 64 bits
 */
    //Rango minimo, tipo.MIN_VALUE
    println(Long.MIN_VALUE)
    //Rango maximo, tipo.MAX_VALUE
    println(Long.MAX_VALUE)

    val miFloat = 55.6f //numero.decimalF
    val miDouble : Double = 66.5
    println(miFloat)
    println(miDouble)

    val miBoolean = true
    val miBool : Boolean = false
    println(miBoolean)
    println(miBool)

    val unCaracter : Char = 'A'
    println(unCaracter)
    val cadenaCaracteres : String = "muchos caracteres"
    println(cadenaCaracteres)

    println(miPrimeraFuncion())
    println(miPrimeraFuncionConParametros(numeroUno,numeroDos,numeroTres))
    miSegundaFuncion()
    miSegundaFuncionConParametros(numeroUno,numeroDos,numeroTres)
    println("en la linea anterior ejecuto una funcion que no retorna nada (Unit -> void)...")

    val pruebaComida = Comida()
    //pruebaComida.numeroDeComida = 1
    //pruebaComida.tipoComida = "comida"

    println(pruebaComida.tipoComida)
    println(pruebaComida.numeroDeComida)

    //var funcionExterna = funcionDePrueba()
    //println(funcionExterna)
    println(funcionDePrueba())

    val pruebaEnum = ValorNumeroComida.Desayuno
    println(pruebaEnum)
    println(pruebaEnum.numeroComida)

    //val pruebaSealed =


}

/*
fun -> indica que es una funcion de kotlin
miPrimeraFuncion -> nombre de la funcion
() -> entre parentesis, indica los parametrso que requiere la funcion
    Si esta vacio o sin parametros, es porque no los requiere.
String -> Es el tipo de retorno de la funcion
return "Ingreso a mi primera funcion" -> el objeto que retorna la funcion
* */
fun miPrimeraFuncion(): String{
    return "Ingreso a mi primera funcion"
}

fun miPrimeraFuncionConParametros(n1: Int, n2: Int, n3: Int): Int{
    val suma = n1 + n2 + n3
    return suma
}

//Unit en Kotlin es la variable primitiva "void" de java
//fun nombreFuncion(...): Unit {...} o
//fun nombreFuncion(...)
fun miSegundaFuncion() {
    println("Ingreso a mi segunda funcion")
}

fun miSegundaFuncionConParametros(n1: Int, n2: Int, n3: Int): Unit{
    val suma = n1 + n2 + n3
    println("Soy una funcion que no retorna nada, pero dentro realizo una suma $suma")
}

