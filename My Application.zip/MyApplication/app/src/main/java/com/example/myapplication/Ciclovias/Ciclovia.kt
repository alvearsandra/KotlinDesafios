package com.example.myapplication.Ciclovias

/**
 * Created by ciromine on 8/26/19.
 */
class Ciclovia(var nombre: String, var comuna: String)
