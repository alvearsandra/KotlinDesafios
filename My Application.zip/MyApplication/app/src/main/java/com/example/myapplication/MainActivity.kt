package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.example.myapplication.Ciclovias.Ciclovia
import com.example.myapplication.Ciclovias.SetupCiclovias
import java.util.ArrayList

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val test = SetupCiclovias()
        val lista = test.init()


        val ciclovia1 : TextView = findViewById(R.id.testView1)
        val ciclovia2 : TextView = findViewById(R.id.testView2)
        val ciclovia3 : TextView = findViewById(R.id.testView3)
        val ciclovia4 : TextView = findViewById(R.id.testView4)
        val ciclovia5 : TextView = findViewById(R.id.testView5)
        val ciclovia6 : TextView = findViewById(R.id.testView6)
        val ciclovia7 : TextView = findViewById(R.id.testView7)
        val ciclovia8 : TextView = findViewById(R.id.testView8)
        val ciclovia9 : TextView = findViewById(R.id.testView9)
        val ciclovia10 : TextView = findViewById(R.id.testView10)
        val ciclovia11 : TextView = findViewById(R.id.testView11)

        val filtro_btn : Button = findViewById(R.id.las_condes_btn)
        val sinfiltro_btn : Button = findViewById(R.id.lista_btn)

        fun sinfiltrar() {
            for (item in lista) {
                println("La ${item.nombre} corresponde a ${item.comuna}")
                //Asignando texto a textView
                when (item.nombre) {
                        "Ciclovia 1" -> ciclovia1.setText(item.nombre + "\n" + item.comuna)
                        "Ciclovia 2" -> ciclovia2.setText(item.nombre + "\n" + item.comuna)
                        "Ciclovia 3" -> ciclovia3.setText(item.nombre + "\n" + item.comuna)
                        "Ciclovia 4" -> ciclovia4.setText(item.nombre + "\n" + item.comuna)
                        "Ciclovia 5" -> ciclovia5.setText(item.nombre + "\n" + item.comuna)
                        "Ciclovia 6" -> ciclovia6.setText(item.nombre + "\n" + item.comuna)
                        "Ciclovia 7" -> ciclovia7.setText(item.nombre + "\n" + item.comuna)
                        "Ciclovia 8" -> ciclovia8.setText(item.nombre + "\n" + item.comuna)
                        "Ciclovia 9" -> ciclovia9.setText(item.nombre + "\n" + item.comuna)
                        "Ciclovia 10" -> ciclovia10.setText(item.nombre + "\n" + item.comuna)
                }
            }
        }

        filtro_btn.setOnClickListener {
            val filtroLasCondes = lista.filter { it.comuna == "Las Condes" }
            var comunas_filtro = ArrayList<String>()
            for (item in filtroLasCondes) {
                println("La " + item.nombre + " corresponde a " + item.comuna)
                comunas_filtro.add(item.nombre)
            }
            println(comunas_filtro)
            ciclovia11.text = "Ciclovias en Las Condes: " + comunas_filtro.toString()
        }

        sinfiltro_btn.setOnClickListener {
            sinfiltrar()
            ciclovia11.text = " "
        }

    }

}
