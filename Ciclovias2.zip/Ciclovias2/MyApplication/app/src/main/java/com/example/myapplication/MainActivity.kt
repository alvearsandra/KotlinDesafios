package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.example.myapplication.Ciclovias.Ciclovia
import com.example.myapplication.Ciclovias.SetupCiclovias
import com.example.myapplication.databinding.ActivityMainBinding
import java.lang.StringBuilder
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        val test = SetupCiclovias()
        val lista = test.init()

        fun sinfiltrar() {
            val text = StringBuilder()
            for (item in lista) {
                //println("La ${item.nombre} corresponde a ${item.comuna}")
                var eachItem = "${item.nombre}\n${item.comuna}\n \n"
                text.append(eachItem)
                binding.testView1.setText(text)
            }
        }

        binding.invertirBtn.setOnClickListener {
                var listaOrdenada = lista.sortedWith(compareBy({ it.nombre }))
                for (obj in listaOrdenada) {
                    println(obj.nombre)
                }
                val text = StringBuilder()
                for (item in listaOrdenada) {
                    var eachItem = "${item.nombre}\n${item.comuna}\n \n"
                    text.append(eachItem)
                    binding.testView1.setText(text)
                }
        }

        /*
        binding.lasCondesBtn.setOnClickListener {
            val filtroLasCondes = lista.filter { it.comuna == "Las Condes" }
            var comunas_filtro = ArrayList<String>()
            for (item in filtroLasCondes) {
                comunas_filtro.add(item.nombre)
            }
            binding.testView11.text = "Ciclovias en Las Condes: " + comunas_filtro.toString()
        }

        binding.listaBtn.setOnClickListener {
            sinfiltrar()
            binding.testView11.text = ""
        }
        */

        val comunasLista = arrayListOf("Todas", "Las Condes", "La Reina",
            "Ñuñoa", "Macul", "Providencia")

    }

}
